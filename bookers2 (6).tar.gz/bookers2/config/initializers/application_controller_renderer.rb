# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '1adc23c5d9b9129a2d2466ab6ef319d1b23e4a004d464b5f9fa73e774253815d8f3aab65a8cc6db5a383698c9cc5287c02abec2bb6815bf646b8c37f9b0eb778'
